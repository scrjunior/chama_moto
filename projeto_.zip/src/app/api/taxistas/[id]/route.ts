import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";

export async function GET(
  _req: Request,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const taxistaId = String(id ?? "").trim();

    if (!taxistaId) {
      return NextResponse.json({ error: "ID inválido." }, { status: 400 });
    }

    const taxista = await prisma.taxista.findUnique({
      where: { id: taxistaId },
      include: { moto: true },
    });

    if (!taxista) {
      return NextResponse.json({ error: "Taxista não encontrado." }, { status: 404 });
    }

    return NextResponse.json({
      ok: true,
      taxista: {
        id: taxista.id,
        nome: taxista.nome,
        apelido: taxista.apelido,
        email: taxista.email,
        documento: taxista.documento,
        disponivel: taxista.disponivel,
        moto: taxista.moto
          ? { nomeMoto: taxista.moto.nomeMoto, matricula: taxista.moto.matricula }
          : null,
      },
    });
  } catch {
    return NextResponse.json({ error: "Erro ao buscar taxista." }, { status: 500 });
  }
}